/* Separate beta cache namespace: never delete the classic site's shell caches. */
const CACHE='f1d-beta-shell-3.1.6-beta.4';
const ROOT=new URL('./',self.location.href),INDEX=new URL('index.html',ROOT).href;
const SHELL=['index.html','race3d-beta.js','race3d-beta.css','f1d-growth.js','f1d-leaderboard.js','manifest.webmanifest','icons/f1-dynasty-192.png','icons/f1-dynasty-512.png'];
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);await Promise.all(SHELL.map(async file=>{const req=new Request(new URL(file,ROOT),{cache:'reload'}),res=await fetch(req);if(!res.ok)throw Error('Incomplete beta shell');await cache.put(req,res);}));await self.skipWaiting();
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 await Promise.all((await caches.keys()).filter(k=>k.startsWith('f1d-beta-shell-')&&k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 const req=event.request,u=new URL(req.url);if(req.method!=='GET'||u.origin!==ROOT.origin||!u.pathname.startsWith(ROOT.pathname))return;
 if(['code','access_token','refresh_token','error','token_hash'].some(k=>u.searchParams.has(k)))return;
 const rel=u.pathname.slice(ROOT.pathname.length),nav=req.mode==='navigate'&&(rel===''||rel==='index.html');
 if(!nav&&!SHELL.includes(rel)&&!/^locales\/[a-zA-Z-]+\.json$/.test(rel))return;
 event.respondWith((async()=>{const cache=await caches.open(CACHE),key=nav?INDEX:req;try{const r=await fetch(req,{cache:'no-cache'});if(r.ok){try{await cache.put(key,r.clone());}catch{}return r;}if(r.status<500)return r;return await cache.match(key)||r;}catch(e){const r=await cache.match(key);if(r)return r;throw e;}})());
});
